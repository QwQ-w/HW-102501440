

# 第二次挑战

## 环境信息：

* GPU 型号：NVIDIA GeForce RTX 5060

* Python版本：3.11.16

* SGLang：0.5.14

* Ray：2.56.0

## 安装方法：

* Python 库安装

```
pip install transfomers asyncio aiohttp
```

## 启动与回放命令：

* 启动 SGLnag:

```bash
python -m sglang.launch_server --model-path Qwen/Qwen3-0.6B --host 0.0.0.0 --port 30000
```

* 回放命令：

```bash
python radix_cache.py
```

## 脚本用途:

### radix_cache.py 脚本构建两组实验数据，并行发送推理请求，自动采集推理延迟、吞吐量、KV 缓存命中率等性能指标，用于对比开启 / 关闭 Radix Cache 的性能差异。

## 结果目录与报告表格的对应关系：

- HW2-102501440/

  - README.md

  - report.pdf                                                                  两个任务的实验、流程图、分析和实验感受

  - AI 使用说明情况（第二次挑战）.pdf

  - src/

    - target1.txt                                                              任务一的实验脚本代码

  - results/

    - target1/                                                                  任务一实验数据

      - dispersed_prefix.txt                                          分散前缀实验数据

      - shared_prefix.txt                                               共享前缀实验数据

    - target2/

      - 流程图.pdf                                                         任务二的流程图


